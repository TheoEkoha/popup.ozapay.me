import React,{ useCallback, useRef, useState,useEffect, useContext } from "react";
import styles from "./Contact.module.css";
import { DataContext } from "../../components/Context";
import axios from "axios";
import { useForm } from "react-hook-form";
import Head from "next/head";

export default function Contact() {
      const [mailSent, setMailSent] = useState(false);
	  
  const {
    register: registerProfile,
    handleSubmit: handleSubmitProfile,
    formState: { errors: errorsProfile },
  } = useForm();
 
	
useEffect(() => { 
    setTimeout(() => {
       setMailSent(false)
    }, 8000);
}, [mailSent]);	
  const username = useRef();
  const wallet = useRef();
  const email = useRef();
  const message = useRef();
  const phone = useRef();
  const subjectType = useRef();
  const societe = useRef();
  const [notification, setNotification] = useState("");
  
  /*const { executeRecaptcha } = useGoogleReCaptcha();

const handleSubmitForm = useCallback(
  (e) => {
    e.preventDefault();
    if (!executeRecaptcha) {
      console.log("Execute recaptcha not yet available");
      return;
    }
    executeRecaptcha("enquiryFormSubmit").then((gReCaptchaToken) => {
      
      submitEnquiryForm(gReCaptchaToken);
    });
  },
  [executeRecaptcha]
);*/
const options = [
  {value: '', text: 'Investir sur Ozalentour'},
  {value: "demande de support", text: "Demande de support"},
  {value: "envoi de candidature", text: "Envoi de candidature"},
  {value: "Participer à l'ICO", text: "Participer à l'ICO"},
];

const [selected, setSelected] = useState(options[0].value);

const handleChange = event => {
  /* console.log(event.target.value); */
  setSelected(event.target.value);
};
const onSubmitProfile = (data) => {
    let langue ="fr";    
	let Username= username.current.value;
    let Email = email.current.value;
    let Societe=societe.current.value;
    let Message=message.current.value;
    let Phone= phone.current.value;
    let Wallet = wallet.current.value;
    let SubjectType= subjectType.current.value;
          console.log(Username,Email);
      axios
      .post(
        `https://apin92.ozalentour.com/contact`,
        {
          
          username: Username,
          email : Email,
          societe:Societe,
          message:Message,
          phone: Phone,
          wallet : Wallet,
          subjectType: SubjectType,
          langue:langue,
},
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        console.log(response);
		 setMailSent(true);
		  setNotification(true);
      });
	  res.json(true)
  };
  return (
	   <>
	  <Head>
  <title>{"Contacter la Startup Lilloise - Ozalentour"}</title>
  <meta name="description" content="Vous souhaiter prendre contact avec notre entreprise ? C'est possible ! Laissez-nous votre message ou rejoignez dès maintenant nos groupes de réseaux sociaux ! (Telegram, Facebook...)
"/>
  <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"/>
  <meta name="keywords" content="Contact Ozalentour"/>
  <meta property="og:url" content="https://fr.ozalentour.com/" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="Contacter la Startup Lilloise - Ozalentour" />
  <meta property="og:description" content="Prendre contact avec Ozalentour maintenant !" />
  <meta property="og:site_name" content="Ozalentour®" />
  <meta property="og:image" content="https://fr.ozalentour.com/public/contacts.jpg"/>
  <meta property="og:image:secure_url" content="https://fr.ozalentour.com/public/contacts.jpg"/>
  <meta property="og:image:type" content="image/jpg" />
  <meta property="og:image:alt" content="Contact Ozalentour" />
  <meta property="fb:app_id" content="2500591266698535" />
  <meta property="article:publisher" content="https://www.facebook.com/Ozalentourfr/" />
  <meta name="twitter:site" content="@ozalentour"/>
  <meta name="twitter:card" content="summary" />
  <meta name="twitter:title" content="Contacter la Startup Lilloise - Ozalentour" />
  <meta name="twitter:description" content="Prendre contact avec Ozalentour maintenant !" />
  <meta name="twitter:image" content="https://fr.ozalentour.com/public/contacts.jpg"/>
  <meta name="twitter:image:alt" content="Contact Ozalentour"/>
  <link rel="shortcut icon" href="/public/favicon.ico" />
      </Head>
     
	  
    <div className={styles.banner}>
      
      <div className={styles.pageTitleContent}>
        <h1 className={styles.pageTitleContent.h1}>
          {"Contact Ozalentour"}
        </h1>
        <p className={styles.pageTitleContent.p}>
        {"Une question ? Vous souhaitez investir ? C'est par ici" }
        </p>
      </div>
    </div>
  
    
      
        <div className={styles.Profile}>
          <div>
            <div className={styles.TopTitle}>
              <h2>{"Posez votre question"}</h2>
            </div>
            <form onSubmit={handleSubmitProfile(onSubmitProfile)}>
            <div className={styles.fieldInline}>
                
                  <input placeholder="Société" ref={societe} className={styles["loginInput"] + " " + styles["loginInputMid"]} ></input>
                
               
                  <input className={styles["loginInput"] + " " + styles["loginInputMid"] }
                  type="text"
                  
                  placeholder="Nom, prénom"
                  ref={username}
                />
                <span className={styles["required"] + " " + styles["requiredName"]}></span>
              </div>
              
              <div className={styles.fieldInline}>
              
                  
                <select required="true" ref={subjectType} className={styles["loginInput"] + " " + styles["loginInputMid"] + " " + styles["selectInput"]} value={selected} onChange={handleChange}>
                  {options.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.text}
                  </option>
                  ))}
                  
                </select>
                
                <span className={styles["required"] + " " + styles["requiredSelect"]}></span>
                <input className={styles["loginInput"] + " " + styles["loginInputMid"]}
                  type="text"
                  
                  placeholder="Clé publique OZACOIN (BSC)"
                  ref={wallet}
                />

              </div>
                
        
              
			  
              <input className={styles["loginInput"] + " " + styles["loginInputFull"]}
                type="email"
                placeholder="Email"
                ref={email}
				        required="true"
              />
              <span className={styles["required"] + " " + styles["requiredSimple"]}></span>
                <input className={styles["loginInput"] + " " + styles["loginInputFull"]}
                  type="number"
                  placeholder="Téléphone"
                  ref={phone}
                  required="true"
                />
              <span  className={styles["required"] + " " + styles["requiredSimple"]}></span>
                <input type="textarea" className={styles.textarea} required="true"
                  placeholder={selected == "Participer à l'ICO" ? "Montant souhaité en euros( participation uniquement par virement/crypto)" : "Message"}
                  ref={message}
                />
              <span className={styles["required"] + " " + styles["requiredTextarea"]}></span>
              
              <button type="submit" className={styles.loginButton}>
                Envoyer
              </button>

				{mailSent ? (
                        <span className={styles.mailPopup}>
                          {"Votre mail a bien été envoyé"}
                        </span>
                      ):null}

              {notification && <p>{notification}</p>}
            </form>
         
        </div>
        </div>
 
   
    </>
  );
}