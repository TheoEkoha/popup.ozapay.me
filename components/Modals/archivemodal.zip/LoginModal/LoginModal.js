import styles from "./LoginModal.module.css";
import { useForm } from "react-hook-form";
import axios from "axios";
import { HiX } from "react-icons/hi";
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";
import { useState, useContext, useEffect } from "react";
import { DataContext } from "../../Context";
import { setCookies, getCookie, getCookies } from "cookies-next";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

export default function LoginModal() {
  const {
    loginModal,
    setLoginModal,
    lostPasswordModal,
    setLostPasswordModal,
    token,
    setToken,
    userData,
    setUserData,
  } = useContext(DataContext);

  useEffect(() => {
    document.body.style.overflow = loginModal ? "hidden" : "scroll";
  }, [loginModal]);



  const [formStep, setFormStep] = useState(0);
  const [registerData, setRegisterData] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [loginPicture, setLoginPicture] = useState(false);
  const [showModal, setShowModal] = useState("login");
  const [phone, setPhone] = useState("");
  const [registerSuccess, setRegisterSuccess] = useState(false);
  const [showPasswordError, setShowPasswordError] = useState(false);

  useEffect(() => { 
    setTimeout(() => {
      setShowPasswordError(false)
    }, 2000);
}, [showPasswordError]);

  // Config for forms using React-hook-form
  const {
    register: registerLogin,
    handleSubmit: handleSubmitLogin,
    formState: { errors: errorsLogin },
  } = useForm();

  const {
    register: registerEmail,
    handleSubmit: handleSubmitRegisterEmail,
    formState: { errors: errorsRegisterEmail },
  } = useForm();

  const {
    register: registerEmailCode,
    handleSubmit: handleSubmitRegisterEmailCode,
    formState: { errors: errorsRegisterEmailCode },
  } = useForm();

  const {
    register: registerPhone,
    handleSubmit: handleSubmitRegisterPhone,
    formState: { errors: errorsRegisterPhone },
  } = useForm();

  const {
    register: registerPhoneCode,
    handleSubmit: handleSubmitRegisterPhoneCode,
    formState: { errors: errorsRegisterPhoneCode },
  } = useForm();

  const {
    register: registerUserInfos,
    handleSubmit: handleSubmitRegisterUserInfos,
    formState: { errors: errorsRegisterUserInfos },
    watch,
  } = useForm();

  // We get user email and password from the login form and perform a request to obtain a json web token
  const onSubmitLogin = (data) => {
    //console.log(data);
    axios
      .post(
        `https://apin92.ozalentour.com/login`,
        {
          email: data.email,
          password: data.password,
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (resultat) {
		let llogintoken=resultat.data.token;
        let loginToken = setCookies("token",llogintoken);

        axios
          .post(
            `https://apin92.ozalentour.com/userData`,
            {
              token: llogintoken,
            },
            {
              withCredentials: true,
              headers: {
                "Content-Type": "application/json; charset=UTF-8",
              },
            }
          )
          .then(function (response) {
            setCookies("OZP", response.data.OZP);
            setCookies("publicKey", response.data.publicKey);
            setCookies("firstName", response.data.firstName);
            setCookies("lastName", response.data.lastName);

            //console.log(getCookies());

            setToken(true);
            setLoginModal(0);
          })
          .catch(function (error) {
            console.log(error);
          });
      })
      .catch(function (error) {
        setShowPasswordError(true);
       
        
      });
  };

  // We handle form datas and update the registerData state with it. Then, we change the formStep number to display the next part of the register tunnel

  const onSubmitRegisterEmail = (data) => {
    let email = data.registerEmail;
    setRegisterData({ email: email });

    axios
      .post(
        `https://apin92.ozalentour.com/mailCode`,
        {
          email: email,
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        //console.log(response.data);
        setFormStep(1);
      });
  };

  const onSubmitRegisterEmailCode = (infos) => {
    let visitorData = registerData.email;
    let visitorCode = infos.emailCode;
    //console.log(registerData);
    axios
      .post(
        `https://apin92.ozalentour.com/verifyCode`,
        {
          visitorData,
          visitorCode,
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        //console.log(response.data);
        setFormStep(2);
      });
  };

  const onSubmitRegisterPhone = (data) => {
    let phoneNumber = `+${phone}`;
    //console.log(phoneNumber);
    setRegisterData(() => ({ ...registerData, phoneNumber }));

    axios
      .post(
        `https://apin92.ozalentour.com/phoneCode`,
        {
          phone: phoneNumber,
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        //console.log(response.data);
        setFormStep(3);
      });
  };

  const onSubmitRegisterPhoneCode = (infos) => {
    let visitorData = registerData.phoneNumber;
    let visitorCode = infos.phoneCode;
    axios
      .post(
        `https://apin92.ozalentour.com/verifyCode`,
        {
          visitorData,
          visitorCode,
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        //console.log(response.data);
        setFormStep(4);
      });
  };

  const onSubmitRegisterUserInfos = async (infos) => {
    let firstName = infos.firstName;
    let lastName = infos.lastName;
    let password = infos.password;
    let city = infos.city;
    let company = infos.company || null;
    let siret = infos.siret || null;
    let phoneNumber = registerData.phoneNumber;
    let email = registerData.email;

    let data = {
      firstName,
      lastName,
      password,
      city,
      company,
      siret,
      phoneNumber,
      email,
    };

    axios
      .post(
        `https://apin92.ozalentour.com/register`,
        {
          data: data,
        },
        {
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        setRegisterSuccess(true);

        setTimeout(() => {
          setShowModal("login");
        }, 2000);
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  let showRegister = () => {
    setShowModal("register");
    setLoginPicture(true);
  };

  return (
    <>
      {/* ----------------------------------------------------------------------------------------
    *************************************** LOGIN ************************************************
    ------------------------------------------------------------------------------------------ */}
      {loginModal === 1 ? (
        showModal == "login" ? (
          <div className={styles.modalBackground}>
            <div className={styles.modalContainer}>
              <div className={styles.modalLeft}>
                <img src="oza-logo.png" alt="logo" />
                <h3>{"Se connecter"}</h3>
                <p>
                  {
                    "Rejoignez Ozalentour et Profitez de la 1ère app de paiement qui réinvente les échanges de proximité !"
                  }
                  
                </p>

                <form onSubmit={handleSubmitLogin(onSubmitLogin)}>
                  <div className={styles.fullInput}>
                    <label className={styles.loginLabel}>
                      {"ADRESSE EMAIL"}
					</label>
                      <input
                        className={styles.loginInput}
                        type="email"
                        placeholder="adresse@fai.com"
                        {...registerLogin("email", {
                          required: true,
                          pattern:
                            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                        })}
                       
                      />
                       
                    
                    {errorsLogin.email && (
                      <span className={styles.formErrors}>
                        {"Merci de renseigner votre adresse email"}
                      </span>
                    )}
                  </div>
                  
                  <div className={styles.fullInput}>
                    <label className={styles.loginLabel}>{"MOT DE PASSE"}</label>
                    <i
                      className={styles.inputEye}
                      onClick={() => {
                        setShowPassword(!showPassword);
                      }}
                    >
                      {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                    </i>

                    <input
                      className={styles.loginInput}
                      type={showPassword == false ? "password" : "text"}
                      placeholder="********"
                      {...registerLogin("password", {
                        required: true,
                        // pattern:
                        //   /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^:;,?µ£¨<>+=&-*]).{12,}$/,
                      })}
                    />
                    
                  </div>
                  {showPasswordError ? <p className={styles.modalPasswordError}>Votre mot de passe est incorrect</p>: null}
                  {errorsLogin.password && (
                    <span className={styles.formErrors}>
                      {" Merci de renseigner votre mot de passe"}
                    </span>
                  )}
                  <div className={styles.loginFormButtons}>
                    <input
                      type="button"
                      className={styles.registerButton}
                      value="Ouvrir un compte"
                      onClick={() => {
                        showRegister();
                      }}
                    />
                    <input
                      type="submit"
                      className={styles.loginButton}
                      value="Se connecter"
                      onSubmit={onSubmitLogin}
                    />
                  </div>
                </form>
                <div className={styles.lostPasswordContainer}>
                  <p className={styles.lostPassword}>
                    {"Mot de passe perdu ? "}
                  </p>
                  <p
                    className={styles.lostPasswordButton}
                    onClick={() => {
                      setLoginModal(0), setLostPasswordModal(true);
                    }}
                  >
                    {"Réinitialiser mon mot de passe"}
                  </p>
                  <p className={styles.version}>{"Version 0.42.a"}</p>
                </div>
              </div>
              <div className={styles.modalRight}>
                <HiX
                  className={styles.closeModal}
                  onClick={() => {
                    setLoginModal(0), setFormStep(0);
                  }}
                />
              </div>
            </div>
          </div>
        ) : (
          // --------------------------------------------------------------------------------------------
          // ************************************* REGISTER *********************************************
          // --------------------------------------------------------------------------------------------

          // ************************************* FIRST STEP : EMAIL ***********************************
          <div className={styles.modalBackground}>
            <div className={styles.modalContainer}>
              <div className={styles.modalLeft}>
                <img src="oza-logo.png" alt="logo" />
                <h3>{"Entrez dans un nouveau monde !"}</h3>
                <p>
                  {"Rejoignez Ozalentour, Lancez votre Activité et Profitez de"}
                  {"votre Portefeuille OZAPHYRE (OZP)"}
                </p>

                <div className={styles.progressBar}>
                  <div
                    className={
                      formStep == 0 || formStep == 1
                        ? styles.progressDotActive
                        : styles.progressDot
                    }
                  />
                  <div
                    className={
                      formStep == 2 || formStep == 3
                        ? styles.progressDotActive
                        : styles.progressDot
                    }
                  />
                  <div
                    className={
                      formStep == 4
                        ? styles.progressDotActive
                        : styles.progressDot
                    }
                  />
                </div>
                {formStep == 0 || formStep == 1 ? (
                  <>
                    <form
                      onSubmit={handleSubmitRegisterEmail(
                        onSubmitRegisterEmail
                      )}
                    >
                      <div className={styles.fullInput}>
                        <label className="loginLabel">
                          {"ADRESSE EMAIL"}
				  		</label>
                          <input
                            className={styles.loginInput}
                            type="email"
                            placeholder="adresse@fai.com"
                            {...registerEmail("registerEmail", {
                              required: true,
                              // pattern:
                              //   /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                            })}
                          />
                       
                        {errorsRegisterEmail.exampleRequired && (
                          <span className={styles.formErrors}>
                            {"Cette adresse email n'est pas valide"}
                          </span>
                        )}
                      </div>

                      <div className={styles.checkBoxForm}>
                        <div>
                          <input
                            type="checkbox"
                            className={styles.checkBox}
                            {...registerEmail("agree", {
                              required: true,
                            })}
                          />
                          <label className={styles.loginLabel}>
                            {
                              "J'accepte les Conditions Générales de Vente ainsi"
                            }
                            {"que les Conditions Générales d'Utilisation."}
                          </label>
                        </div>
                        {errorsRegisterEmail.agree && (
                          <span className={styles.formErrors}>
                            {"Merci d'accepter les conditions générales"}
                          </span>
                        )}
                        {formStep == 0 ? (
                          <div className={styles.loginFormButtons}>
                            <input
                              type="submit"
                              className={styles.loginButton}
                              value="Continuer"
                            />
                          </div>
                        ) : null}
                      </div>
                    </form>
                    {formStep == 0 ? (
                      <div className={styles.lostAccount}>
                        <a 
					 className={styles.lostPasswordButton}
                    onClick={() => {
                      setLoginModal(0), setLostPasswordModal(true);
                    }}>{"Récupérer un compte perdu"}</a>
                        <p
                          onClick={() => {
                            setLoginModal(1);
                          }}
                        >
                          {"Vous avez déjà un Compte "}
                          <span  className={styles.lostPasswordButton}
							onClick={() => {
                            setShowModal("login"),setLoginModal(1);
                          }}
						>{"Se connecter"}</span>
                        </p>
                      </div>
                    ) : null}
                  </>
                ) : null}
                {formStep === 1 ? (
                  <form
                    onSubmit={handleSubmitRegisterEmailCode(
                      onSubmitRegisterEmailCode
                    )}
                  >
                    <div className={styles.fullInput}>
                      <label className={styles.loginLabel}>
                        {"CODE DE VERIFICATION EMAIL"}
				 	  </label>
                        <input
                          className={styles.loginInput}
                          type="text"
                          placeholder="ex: 000000"
                          {...registerEmailCode("emailCode", {
                            required: true,
                          })}
                        />
                      
                      {errorsRegisterEmailCode.exampleRequired && (
                        <span className={styles.formErrors}>
                          {" This field is required"}
                        </span>
                      )}
                    </div>

                    <div className={styles.emailStepButtons}>
                      <div className={styles.registerFormButtons}>
                        <input
                          type="button"
                          className={styles.resendButton}
                          value="Renvoyer"
                        />
                      </div>
                      <div className={styles.registerFormButtons}>
                        <input
                          type="submit"
                          className={styles.loginButton}
                          value="Continuer"
                        />
                      </div>
                    </div>
                  </form>
                ) : null}

                {/* ************************************* STEP 2 : PHONE *********************************** */}

                {formStep === 2 || formStep === 3 ? (
                  <form
                    onSubmit={handleSubmitRegisterPhone(onSubmitRegisterPhone)}
                  >
                    <div className={styles.fullInputPhone}>
                      <label className={styles.loginLabel}>
                        {"TELEPHONE"}
                        {/* <input
                          className={styles.loginInput}
                          type="tel"
                          placeholder="ex: 065484 ..."
                          {...registerPhone("phoneNumber", {
                            required: true,
                            // pattern: /^\+(?:[0-9]?){6,14}[0-9]$/,
                          })}
                        /> */}
                        <PhoneInput
                          country={"fr"}
                          value={phone}
                          onChange={(phone) => setPhone(phone)}
                          containerStyle={{ width: "100%" }}
                          inputStyle={{
                            padding: ".8rem .5rem .5rem 3rem",
                            border: "none",
                            width: "100%",

                            margin: "1rem 0 .8rem 0",
                            borderRadius: "1rem",
                            backgroundColor: "#FFFFFF",
                          }}
                          buttonStyle={{
                            marginTop: ".5rem",
                            borderRadius: ".3rem",
                          }}
                        />
                      </label>
                      {errorsRegisterPhone.exampleRequired && (
                        <span className={styles.formErrors}>
                          {"This field is required"}
                        </span>
                      )}
                    </div>
                    {formStep === 2 ? (
                      <div className={styles.loginFormButtons}>
                        <input
                          type="submit"
                          className={styles.loginButton}
                          value="Continuer"
                        />
                      </div>
                    ) : null}
                  </form>
                ) : null}
                {formStep === 3 ? (
                  <form
                    onSubmit={handleSubmitRegisterPhoneCode(
                      onSubmitRegisterPhoneCode
                    )}
                  >
                    <div className={styles.fullInput}>
                      <label className={styles.loginLabel}>
                        {"CODE DE VERIFICATION SMS"}
				 	</label>
                        <input
                          className={styles.loginInput}
                          type="text"
                          placeholder="ex: 000000"
                          {...registerPhoneCode("phoneCode", {
                            required: true,
                          })}
                        />
                      
                      {errorsRegisterPhoneCode.exampleRequired && (
                        <span className={styles.formErrors}>
                          {"This field is required"}
                        </span>
                      )}
                    </div>
                    <div className={styles.emailStepButtons}>
                      <div className={styles.loginFormButtons}>
                        <input
                          type="button"
                          className={styles.resendButton}
                          value="Renvoyer"
                        />

                        <input
                          type="submit"
                          className={styles.loginButton}
                          value="Continuer"
                        />
                      </div>
                    </div>
                  </form>
                ) : null}

                {/* ************************************* STEP 3 : USER INFOS *********************************** */}
                {formStep === 4 ? (
                  <>
                    <p
                      className={
                        registerSuccess
                          ? styles.registerMessage
                          : styles.hideRegisterMessage
                      }
                    >
                      {
                        " Votre compte a été créé, merci pour votre inscription !"
                      }
                    </p>
                    <form
                      className={
                        registerSuccess
                          ? styles.hideForm
                          : styles.finalRegisterForm
                      }
                      onSubmit={handleSubmitRegisterUserInfos(
                        onSubmitRegisterUserInfos
                      )}
                    >
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"NOM DE FAMILLE"}
				 		</label>
                          <input
                            className={styles.loginInput}
                            type="text"
                            placeholder="ex: Delatour"
                            {...registerUserInfos("lastName", {
                              required: true,
                            })}
                          />
                        
                      </div>
                      {errorsRegisterUserInfos.lastName && (
                        <span className={styles.formErrors}>
                          {"Merci de renseigner votre nom"}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"PRENOM"}
						</label>
                          <input
                            className={styles.loginInput}
                            type="text"
                            placeholder="ex: Michel"
                            {...registerUserInfos("firstName", {
                              required: true,
                            })}
                          />
                        
                      </div>
                      {errorsRegisterUserInfos.firstName && (
                        <span className={styles.formErrors}>
                          {"Merci de renseigner votre prénom"}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"MOT DE PASSE"}
                        </label>
                        <i
                          className={styles.inputEye}
                          onClick={() => {
                            setShowPassword(!showPassword);
                          }}
                        >
                          {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                        </i>
                        <input
                          className={styles.loginInput}
                          type={showPassword == false ? "password" : "text"}
                          placeholder="ex: 4!aK*0b2?7"
                          {...registerUserInfos("password", {
                            required: true,
                            // pattern:
                            // /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^:;,?µ£¨<>+=&-*]).{12,}$/,
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.password && (
                        <span className={styles.formErrors}>
                          {
                            "Votre mot de passe doit contenir au moins 12 caractères,"
                          }
                          {"et au moins un caractère spécial."}
                        </span>
                      )}

                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"CONFIRMER LE MOT DE PASSE"}
                        </label>
                        <i
                          className={styles.inputEye}
                          onClick={() => {
                            setShowPassword(!showPassword);
                          }}
                        >
                          {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                        </i>
                        <input
                          className={styles.loginInput}
                          type={showPassword == false ? "password" : "text"}
                          placeholder="ex: 4!aK*0b2?7"
                          {...registerUserInfos("verifyPassword", {
                            required: true,
                            validate: (value) =>
                              value === watch("password") || "error message",
                            // pattern:
                            //   /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^:;,?µ£¨<>+=&-*]).{12,}$/,
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.verifyPassword && (
                        <span className={styles.formErrors}>
                          {"Les mots de passe doivent ëtre identiques"}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"VILLE"}
						</label>
                          <input
                            className={styles.loginInput}
                            type="text"
                            placeholder="ex: Lille"
                            {...registerUserInfos("city", {
                              required: true,
                            })}
                          />
                        
                      </div>
                      {errorsRegisterUserInfos.city && (
                        <span className={styles.formErrors}>
                          {"Merci de renseigner votre ville"}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"NOM DE L'ENTREPRISE"}
						</label>
                          <input
                            className={styles.loginInput}
                            type="text"
                            placeholder="ex: Boulangerie du Moulin"
                            {...registerUserInfos("company", {})}
                          />
                        
                      </div>
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {"SIRET"}
						</label>
                          <input
                            className={styles.loginInput}
                            type="number"
                            placeholder="ex: 123 456 789 00012"
                            {...registerUserInfos("siret", {})}
                          />
                        
                      </div>
                      <div className={styles.submitRegister}>
                        <input
                          type="submit"
                          className={styles.submitButton}
                          value="S'inscrire"
                        />
                      </div>
                    </form>
                  </>
                ) : null}
              </div>
              <div
                className={
                  !loginPicture ? styles.modalRight : styles.modalRightRegister
                }
              >
                <p className={styles.test}>
                <HiX
                  className={styles.closeModal}
                  onClick={() => {
                    setLoginModal(0),
                      setFormStep(0),
                      setShowModal("login"),
                      setRegisterSuccess(false);
                  }}
                />
                </p>
              </div>
            </div>
          </div>
        )
      ) : null}
    </>
  );
}
