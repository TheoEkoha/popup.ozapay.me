
import styles from "./LoginModal.module.css";
import { useForm } from "react-hook-form";
import axios from "axios";
import { HiX } from "react-icons/hi";
import Link from "next/link";
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";
import { useState, useContext, useEffect, useRef } from "react";
import { DataContext } from "../../Context";
import { setCookies, getCookie, getCookies } from "cookies-next";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import ReCAPTCHA from "react-google-recaptcha";
import variables from "../../../variables.json";
import { useTranslation } from "react-i18next";
export default function LoginModal() {
  const {
    loginModal,
    setLoginModal,
    lostPasswordModal,
    setLostPasswordModal,
    token,
    setToken,
    userData,
    setUserData,
    setWalletId,
  } = useContext(DataContext);
  const { t, i18n } = useTranslation("fr", { useSuspense: false });
  useEffect(() => {
    document.body.style.overflow = loginModal ? "hidden" : "scroll";
  }, [loginModal]);

  const recaptchaRef = useRef(null);
  const [formStep, setFormStep] = useState(0);
  const [registerData, setRegisterData] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [loginPicture, setLoginPicture] = useState(false);
  const [showModal, setShowModal] = useState("login");
  const [phone, setPhone] = useState("");
  const [registerSuccess, setRegisterSuccess] = useState(false);
  const [showPasswordError, setShowPasswordError] = useState(false);
  const [showCodeMailError, setShowCodeMailError] = useState(false);
  const [showCodePhoneError, setShowCodePhoneError] = useState(false);
  const [showCodeError, setShowCodeError] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setShowCodeMailError(false);
    }, 8000);
  }, [showCodeMailError]);

  useEffect(() => {
    setTimeout(() => {
      setShowCodePhoneError(false);
    }, 8000);
  }, [showCodePhoneError]);

  useEffect(() => {
    setTimeout(() => {
      setShowPasswordError(false);
    }, 2000);
  }, [showPasswordError]);

  // Config for forms using React-hook-form
  const {
    register: registerLogin,
    handleSubmit: handleSubmitLogin,
    formState: { errors: errorsLogin },
  } = useForm();

  const {
    register: registerEmail,
    handleSubmit: handleSubmitRegisterEmail,
    formState: { errors: errorsRegisterEmail },
  } = useForm();

  const {
    register: registerEmailCode,
    handleSubmit: handleSubmitRegisterEmailCode,
    formState: { errors: errorsRegisterEmailCode },
  } = useForm();

  const {
    register: registerPhone,
    handleSubmit: handleSubmitRegisterPhone,
    formState: { errors: errorsRegisterPhone },
  } = useForm();

  const {
    register: registerPhoneCode,
    handleSubmit: handleSubmitRegisterPhoneCode,
    formState: { errors: errorsRegisterPhoneCode },
  } = useForm();

  const {
    register: registerUserInfos,
    handleSubmit: handleSubmitRegisterUserInfos,
    formState: { errors: errorsRegisterUserInfos },
    watch,
  } = useForm();

  // We get user email and password from the login form and perform a request to obtain a json web token
  const onSubmitLogin = (data1) => {
    //console.log(data);
    let data = {
      email: data1.email,
      password: data1.password,
    };
    axios
      .post(
        `${variables.DATA_URL}/login/loginTest`,
        {
          data: data,
        },
        {
          //withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (resultat) {
        let llogintoken = resultat.data.token;
        let loginToken = setCookies("token", llogintoken);

        axios
          .post(
            `${variables.DATA_URL}/user/getData`,
            {
              token: llogintoken,
            },
            {
              //withCredentials: true,
              headers: {
                "Content-Type": "application/json; charset=UTF-8",
              },
            }
          )
          .then(function (response) {
            setCookies("EUR", response.data.EUR.toString());
            setCookies("firstName", response.data.firstName);
            setCookies("lastName", response.data.lastName);
            setCookies("walletId", response.data.walletId);
            setCookies("BSCWallet", response.data.BSCWallet);

            setToken(true);
            setWalletId(response.data.walletId);
            setLoginModal(0);
          })
          .catch(function (error) {
            setShowCodeError(true);
          });
      })
      .catch(function (error) {
        setShowPasswordError(true);
      });
  };

  // We handle form datas and update the registerData state with it. Then, we change the formStep number to display the next part of the register tunnel

  const onSubmitRegisterEmail = async (data1) => {
    const captchaToken = await recaptchaRef.current.executeAsync();
    recaptchaRef.current.reset();

    let email = data1.registerEmail;
    setRegisterData({ email: email });
    let data = {
      email: email,
      langue: "fr",
    };

    axios
      .post(
        `${variables.DATA_URL}/register/sendRegisterEmailTest`,
        {
          captchaToken,
          data: data,
        },
        {
          //withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        setFormStep(1);
        setCookies("StepForm", formStep);
      });
  };

  const onSubmitRegisterEmailCode = (infos) => {
    let visitorData = registerData.email;
    let visitorCode = infos.emailCode;
    let data = {
      visitorData,
      visitorCode,
    };
    //console.log(registerData);
    axios
      .post(
        `${variables.DATA_URL}/register/verifyCode`,
        {
          data: data,
        },
        {
          //withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        //console.log(response.data);
        setFormStep(2);
      })
      .catch(function (error) {
        setShowCodeMailError(true);
      });
  };

  const onSubmitRegisterPhone = (data1) => {
    let phoneNumber = `+${phone}`;
    let indicatif = phoneNumber.substr(0, 4);
    //console.log(indicatif);
    setRegisterData(() => ({ ...registerData, phoneNumber }));
    if (
      indicatif === "+225" ||
      indicatif === "+234" ||
      indicatif == "+241" ||
      indicatif == "+229"
    ) {
      setFormStep(4);
    } else {
      let phone = phoneNumber;

      axios
        .post(
          `${variables.DATA_URL}/register/sendRegisterSMS`,
          {
            phone,
          },
          {
            //withCredentials: true,
            headers: {
              "Content-Type": "application/json; charset=UTF-8",
            },
          }
        )
        .then(function (response) {
          //console.log(response.data);
          setFormStep(3);
        });
    }
  };

  const onSubmitRegisterPhoneCode = (infos) => {
    let visitorData = registerData.phoneNumber;
    let visitorCode = infos.phoneCode;
    let data = {
      visitorData,
      visitorCode,
    };
    axios
      .post(
        `${variables.DATA_URL}/register/verifyCode`,
        {
          data: data,
        },
        {
          //withCredentials: true,
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        //console.log(response.data);
        setFormStep(4);
      })
      .catch(function (error) {
        setShowCodePhoneError(true);
      });
  };

  const onSubmitRegisterUserInfos = async (infos) => {
    let firstName = infos.firstName;
    let lastName = infos.lastName;
    let password = infos.password;
    let city = infos.city;
    let company = infos.company || null;
    let siret = infos.siret || null;
    let phoneNumber = registerData.phoneNumber;
    let email = registerData.email;

    let data2 = {
      firstName,
      lastName,
      password,
      city,
      company,
      siret,
      phoneNumber,
      email,
    };

    axios
      .post(
        `${variables.DATA_URL}/register/createUser`,
        {
          data: data2,
          langue: "fr",
        },
        {
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        }
      )
      .then(function (response) {
        setRegisterSuccess(true);

        setTimeout(() => {
          setShowModal("login");
        }, 2000);
      })
      .catch(function (error) {});
  };

  let showRegister = () => {
    setShowModal("register");
    setLoginPicture(true);
  };

  const onlyLettersRegex = /^[A-Za-z]+$/; // regular expression pattern to match only letters
  return (
    <>
      {/* ----------------------------------------------------------------------------------------
    *************************************** LOGIN ************************************************
    ------------------------------------------------------------------------------------------ */}
      {loginModal === 1 ? (
        showModal === "login" ? (
          <div className={styles.modalBackground}>
            <div className={styles.modalContainer}>
              <div className={styles.modalLeft}>
                <img src="ozaLogo.png" alt="logo" />
                <h3>{t("login")}</h3>
                <p>{t("firstTitle")}</p>

                <form onSubmit={handleSubmitLogin(onSubmitLogin)}>
                  <div className={styles.fullInput}>
                    <label className={styles.loginLabel}>
                      {t("mailAdress")}
                    </label>
                    <input
                      className={styles.loginInput}
                      type="email"
                      placeholder={t("mailPlaceholder")}
                      {...registerLogin("email", {
                        required: true,
                        pattern:
                          /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                      })}
                    />
                  </div>
                  {errorsLogin.email && (
                    <span className={styles.formErrors}>{t("emptyMail")}</span>
                  )}
                  <div
                    className={
                      styles["fullInput"] + " " + styles["fullInputBottom"]
                    }
                  >
                    <label className={styles.loginLabel}>{t("password")}</label>
                    <i
                      className={styles.inputEye}
                      onClick={() => {
                        setShowPassword(!showPassword);
                      }}
                    >
                      {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                    </i>

                    <input
                      className={styles.loginInput}
                      type={showPassword === false ? "password" : "text"}
                      placeholder={t("passwordPlaceholder")}
                      {...registerLogin("password", {
                        required: true,
                        pattern:
                          /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^:;,?µ£¨<>+=&*-\x2D]).{12,}$/,
                      })}
                    />
                  </div>
                  {showPasswordError ? (
                    <p className={styles.modalPasswordError}>
                      {t("incorrectPassword")}
                    </p>
                  ) : null}
                  {errorsLogin.password && (
                    <span className={styles.formErrors}>
                      {t("passwordFormat")}
                    </span>
                  )}
                  <div className={styles.loginFormButtons}>
                    <input
                      type="button"
                      className={styles.registerButton}
                      value={t("openAccount")}
                      onClick={() => {
                        showRegister();
                      }}
                    />
                    <input
                      type="submit"
                      className={styles.loginButton}
                      value={t("login")}
                      onSubmit={onSubmitLogin}
                    />
                  </div>
                </form>
                <div className={styles.lostPasswordContainer}>
                  <p className={styles.lostPassword}>{t("lostPassword")}</p>
                  <p
                    className={styles.lostPasswordButton}
                    onClick={() => {
                      setLoginModal(0), setLostPasswordModal(true);
                    }}
                  >
                    {t("reset")}
                  </p>
                  <p className={styles.version}>{t("version")}</p>
                </div>
              </div>
              <div className={styles.modalRight}>
                <HiX
                  className={styles.closeModal}
                  onClick={() => {
                    setLoginModal(0), setFormStep(0);
                  }}
                />
              </div>
            </div>
          </div>
        ) : (
          // --------------------------------------------------------------------------------------------
          // ************************************* REGISTER *********************************************
          // --------------------------------------------------------------------------------------------

          // ************************************* FIRST STEP : EMAIL ***********************************
          <div className={styles.modalBackground}>
            <div className={styles.modalContainer}>
              <div className={styles.modalLeft}>
                <img src="ozaLogo.png" alt="logo" />
                <h3>{t("enter")}</h3>
                <p>
                  {t("accept")}
                  {t("receive")}
                </p>

                <div className={styles.progressBar}>
                  <div
                    className={
                      formStep == 0 || formStep == 1
                        ? styles.progressDotActive
                        : styles.progressDot
                    }
                  />
                  <div
                    className={
                      formStep == 2 || formStep == 3
                        ? styles.progressDotActive
                        : styles.progressDot
                    }
                  />
                  <div
                    className={
                      formStep == 4
                        ? styles.progressDotActive
                        : styles.progressDot
                    }
                  />
                </div>
                {formStep == 0 || formStep == 1 ? (
                  <>
                    <form
                      onSubmit={handleSubmitRegisterEmail(
                        onSubmitRegisterEmail
                      )}
                    >
                      <div className={styles.fullInput}>
                        <label className="loginLabel">
                          {t("mailAdress")}
                        </label>
                        <input
                          className={styles.loginInput}
                          type="email"
                          placeholder={t("mailPlaceholder")}
                          {...registerEmail("registerEmail", {
                            required: true,
                            pattern:
                              /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                          })}
                        />
                        {errorsRegisterEmail.exampleRequired && (
                          <span className={styles.formErrors}>
                            {t("invalidEmail")}
                          </span>
                        )}
                      </div>
                      <ReCAPTCHA
                        ref={recaptchaRef}
                        size="invisible"
                        sitekey="6Lcr1lIiAAAAAGHIHCXvEkyR7RkUBzm5Efp6_sOf"
                      />
                      <div className={styles.checkBoxForm}>
                        <div className={styles.conditions}>
                          <input
                            type="checkbox"
                            className={styles.checkBox}
                            {...registerEmail("agree", {
                              required: true,
                            })}
                          />
                          <label className={styles.loginLabel}>
                            {t("acceptConditions")}{" "}
                            <Link href="pdf/cgv-ozalentour.pdf">
                              {t("conditionsSales")}
                            </Link>{" "}
                            {t("aswell")}{" "}
                            <Link href="pdf/cgu-ozalentour.pdf">
                              {t("conditionsSell")}
                            </Link>
                          </label>
                        </div>
                        {errorsRegisterEmail.agree && (
                          <span className={styles.formErrors}>
                            {t("notAccepted")}
                          </span>
                        )}
                        {formStep == 0 ? (
                          <div className={styles.loginFormButtons}>
                            <input
                              type="submit"
                              className={styles.loginButton}
                              value={t("continue")}
                            />
                          </div>
                        ) : null}
                      </div>
                    </form>
                    {formStep == 0 ? (
                      <div className={styles.lostAccount}>
                        <a
                          className={styles.lostPasswordButton}
                          onClick={() => {
                            setLoginModal(0),
                              setShowModal("login"),
                              setLostPasswordModal(true);
                          }}
                        >
                          {t("recover")}
                        </a>
                        <p
                          onClick={() => {
                            setLoginModal(1);
                          }}
                        >
                          {t("accountExisting")}
                          <span
                            className={styles.lostPasswordButton}
                            onClick={() => {
                              setShowModal("login"), setLoginModal(1);
                            }}
                          >
                            {t("login")}
                          </span>
                        </p>
                      </div>
                    ) : null}
                  </>
                ) : null}
                {formStep === 1 ? (
                  <form
                    onSubmit={handleSubmitRegisterEmailCode(
                      onSubmitRegisterEmailCode
                    )}
                  >
                    <div className={styles.fullInput}>
                      <label className={styles.loginLabel}>
                        {t("codeMail")}
                      </label>
                      <input
                        className={styles.loginInput}
                        type="text"
                        placeholder={t("codeMailPlaceholder")}
                        {...registerEmailCode("emailCode", {
                          required: true,
                        })}
                      />

                      {errorsRegisterEmailCode.exampleRequired && (
                        <span className={styles.formErrors}>
                          {t("required")}
                        </span>
                      )}
                    </div>
                    {showCodeMailError ? (
                      <span className={styles.formErrors}>
                        {t("codeNotValid")}
                      </span>
                    ) : null}
                    <div className={styles.emailStepButtons}>
                      <div className={styles.registerFormButtons}>
                        <input
                          type="button"
                          className={styles.resendButton}
                          value={t("resend")}
                        />
                      </div>
                      <div className={styles.registerFormButtons}>
                        <input
                          type="submit"
                          className={styles.loginButton}
                          value={t("continue")}
                        />
                      </div>
                    </div>
                  </form>
                ) : null}

                {/* ************************************* STEP 2 : PHONE *********************************** */}

                {formStep === 2 || formStep === 3 ? (
                  <form
                    onSubmit={handleSubmitRegisterPhone(onSubmitRegisterPhone)}
                  >
                    <div className={styles.fullInputPhone}>
                      <label className={styles.loginLabel}>
                        {t("phoneNumber")}
                        {/* <input
                          className={styles.loginInput}
                          type="tel"
                          placeholder="ex: 065484 ..."
                          {...registerPhone("phoneNumber", {
                            required: true,
                            // pattern: /^\+(?:[0-9]?){6,14}[0-9]$/,
                          })}
                        /> */}
                        <PhoneInput
                          country={"fr"}
                          value={phone}
                          masks={{ ci: "........." }}
                          onChange={(phone) => setPhone(phone)}
                          containerStyle={{ width: "100%" }}
                          inputStyle={{
                            padding: ".8rem .5rem .5rem 3rem",
                            border: "none",
                            width: "100%",

                            margin: "1rem 0 .8rem 0",
                            borderRadius: "1rem",
                            backgroundColor: "#FFFFFF",
                          }}
                          buttonStyle={{
                            marginTop: ".5rem",
                            borderRadius: ".3rem",
                          }}
                        />
                      </label>
                      {errorsRegisterPhone.exampleRequired && (
                        <span className={styles.formErrors}>
                          {t("required")}
                        </span>
                      )}
                    </div>
                    {showCodePhoneError ? (
                      <span className={styles.formErrors}>
                        {t("codeNotValid")}
                      </span>
                    ) : null}
                    {formStep === 2 ? (
                      <div className={styles.loginFormButtons}>
                        <input
                          type="submit"
                          className={styles.loginButton}
                          value={t("continue")}
                        />
                      </div>
                    ) : null}
                  </form>
                ) : null}
                {formStep === 3 ? (
                  <form
                    onSubmit={handleSubmitRegisterPhoneCode(
                      onSubmitRegisterPhoneCode
                    )}
                  >
                    <div className={styles.fullInput}>
                      <label className={styles.loginLabel}>
                        {t("codePhone")}
                      </label>
                      <input
                        className={styles.loginInput}
                        type="text"
                        placeholder={t("codePhonePlaceholder")}
                        {...registerPhoneCode("phoneCode", {
                          required: true,
                        })}
                      />

                      {errorsRegisterPhoneCode.exampleRequired && (
                        <span className={styles.formErrors}>
                          {t("required")}
                        </span>
                      )}
                    </div>
                    <div className={styles.emailStepButtons}>
                      <div className={styles.loginFormButtons}>
                        <input
                          type="button"
                          className={styles.resendButton}
                          value={t("resend")}
                        />

                        <input
                          type="submit"
                          className={styles.loginButton}
                          value={t("continue")}
                        />
                      </div>
                    </div>
                  </form>
                ) : null}

                {/* ************************************* STEP 3 : USER INFOS *********************************** */}
                {formStep === 4 ? (
                  <>
                    <p
                      className={
                        registerSuccess
                          ? styles.registerMessage
                          : styles.hideRegisterMessage
                      }
                    >
                      {t("accountCreated")}
                    </p>
                    <form
                      className={
                        registerSuccess
                          ? styles.hideForm
                          : styles.finalRegisterForm
                      }
                      onSubmit={handleSubmitRegisterUserInfos(
                        onSubmitRegisterUserInfos
                      )}
                    >
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {t("lastName")}
                        </label>
                        <input
                          className={styles.loginInput}
                          type="text"
                          placeholder={t("lastNamePlaceholder")}
                          {...registerUserInfos("lastName", {
                            required: true,
                            pattern: onlyLettersRegex, // validation rule to allow only letters
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.lastName && (
                        <span className={styles.formErrors}>
                          {t("emptyLastName")}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {t("firstName")}
                        </label>
                        <input
                          className={styles.loginInput}
                          type="text"
                          placeholder={t("firstNamePlaceholder")}
                          {...registerUserInfos("firstName", {
                            required: true,
                            pattern: onlyLettersRegex, // validation rule to allow only letters
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.firstName && (
                        <span className={styles.formErrors}>
                          {t("emptyFirstName")}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {t("password")}
                        </label>
                        <i
                          className={styles.inputEye}
                          onClick={() => {
                            setShowPassword(!showPassword);
                          }}
                        >
                          {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                        </i>
                        <input
                          className={styles.loginInput}
                          type={showPassword ? "text" : "password"}
                          placeholder={t("passwordPlaceholder")}
                          {...registerUserInfos("password", {
                            required: true,
                            pattern:
                              /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^:;,?µ£¨<>+=&-*]).{12,}$/,
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.password && (
                        <span className={styles.formErrors}>
                          {t("passwordFormat")}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {t("confirmPassword")}
                        </label>
                        <i
                          className={styles.inputEye}
                          onClick={() => {
                            setShowPassword(!showPassword);
                          }}
                        >
                          {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                        </i>
                        <input
                          className={styles.loginInput}
                          type={showPassword ? "text" : "password"}
                          placeholder={t("samePasswordPlaceholder")}
                          {...registerUserInfos("verifyPassword", {
                            required: true,
                            validate: {
                              matchesPassword: (value) =>
                                value === watch("password") ||
                                t("samePassword"),
                            },
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.verifyPassword && (
                        <span className={styles.formErrors}>
                          {errorsRegisterUserInfos.verifyPassword.message}
                        </span>
                      )}

                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>{t("city")}</label>
                        <input
                          className={styles.loginInput}
                          type="text"
                          placeholder={t("cityPlaceholder")}
                          {...registerUserInfos("city", {
                            required: true,
                            pattern: /^[A-Za-z\s]+$/, // validation rule to allow only letters
                          })}
                        />
                      </div>
                      {errorsRegisterUserInfos.city && (
                        <span className={styles.formErrors}>
                          {t("emptyCity")}
                        </span>
                      )}
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {t("nameSociety")}
                        </label>
                        <input
                          className={styles.loginInput}
                          type="text"
                          placeholder={t("nameSocietyPlaceholder")}
                          {...registerUserInfos("company", {})}
                        />
                      </div>
                      <div className={styles.fullInput}>
                        <label className={styles.loginLabel}>
                          {t("siret")}
                        </label>
                        <input
                          className={styles.loginInput}
                          type="number"
                          placeholder={t("siretPlaceholder")}
                          {...registerUserInfos("siret", {})}
                        />
                      </div>
                      <div className={styles.submitRegister}>
                        <input
                          type="submit"
                          className={styles.submitButton}
                          value={t("register")}
                        />
                      </div>
                    </form>
                  </>
                ) : null}
              </div>
              <div
                className={
                  !loginPicture ? styles.modalRight : styles.modalRightRegister
                }
              >
                <p className={styles.test}>
                  <HiX
                    className={styles.closeModal}
                    onClick={() => {
                      setLoginModal(0),
                        setFormStep(0),
                        setShowModal("login"),
                        setRegisterSuccess(false);
                    }}
                  />
                </p>
              </div>
            </div>
          </div>
        )
      ) : null}
    </>
  );
}
