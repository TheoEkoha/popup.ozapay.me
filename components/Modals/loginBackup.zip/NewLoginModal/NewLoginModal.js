import styles from "./LoginModal.module.css";
import { useForm } from "react-hook-form";
import axios from "axios";
import { HiX } from "react-icons/hi";
import Link from "next/link";
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";
import { useState, useContext, useEffect, useRef } from "react";
import { DataContext } from "../../Context";
import { setCookies, getCookie, getCookies } from "cookies-next";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import ReCAPTCHA from "react-google-recaptcha";
import variables from "../../../variables.json";
import { useTranslation } from "react-i18next";
export default function NewLoginModal() {
  const {
    newloginModal,
    setNewLoginModal,
    loginModal,
    setLoginModal,
    lostPasswordModal,
    setLostPasswordModal,
    token,
    setToken,
    userData,
    setUserData,
    setWalletId,
  } = useContext(DataContext);
  const { t, i18n } = useTranslation("fr", { useSuspense: false });
  useEffect(() => {
    document.body.style.overflow = loginModal ? "hidden" : "scroll";
  }, [loginModal]);

  const recaptchaRef = useRef(null);
  const [formStep, setFormStep] = useState(0);
  const [registerData, setRegisterData] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [loginPicture, setLoginPicture] = useState(false);
  const [showModal, setShowModal] = useState("login");
  const [phone, setPhone] = useState("");
  const [registerSuccess, setRegisterSuccess] = useState(false);
  const [showPasswordError, setShowPasswordError] = useState(false);
  const [showCodeMailError, setShowCodeMailError] = useState(false);
  const [showCodePhoneError, setShowCodePhoneError] = useState(false);
  const [showCodeError, setShowCodeError] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setShowCodeMailError(false);
    }, 8000);
  }, [showCodeMailError]);

  useEffect(() => {
    setTimeout(() => {
      setShowCodePhoneError(false);
    }, 8000);
  }, [showCodePhoneError]);

  useEffect(() => {
    setTimeout(() => {
      setShowPasswordError(false);
    }, 2000);
  }, [showPasswordError]);

  // Config for forms using React-hook-form
  const {
    register: registerLogin,
    handleSubmit: handleSubmitLogin,
    formState: { errors: errorsLogin },
  } = useForm();

  const {
    register: registerEmail,
    handleSubmit: handleSubmitRegisterEmail,
    formState: { errors: errorsRegisterEmail },
  } = useForm();

  const {
    register: registerEmailCode,
    handleSubmit: handleSubmitRegisterEmailCode,
    formState: { errors: errorsRegisterEmailCode },
  } = useForm();

  const {
    register: registerPhone,
    handleSubmit: handleSubmitRegisterPhone,
    formState: { errors: errorsRegisterPhone },
  } = useForm();

  const {
    register: registerPhoneCode,
    handleSubmit: handleSubmitRegisterPhoneCode,
    formState: { errors: errorsRegisterPhoneCode },
  } = useForm();

  const {
    register: registerUserInfos,
    handleSubmit: handleSubmitRegisterUserInfos,
    formState: { errors: errorsRegisterUserInfos },
    watch,
  } = useForm();
  console.log(loginModal);
  return (
    <>
      {/* ----------------------------------------------------------------------------------------
    *************************************** LOGIN ************************************************
    ------------------------------------------------------------------------------------------ */}
      {loginModal && (
        <div className={styles.modalBackground}>
          <div className={styles.modalContainer}>
            <div className={styles.modalLeft}>
              <img src="ozaLogo.png" alt="logo" />
              <h3>{t("login")}</h3>
              <p>{t("firstTitle")}</p>

              <form onSubmit={handleSubmitLogin(onSubmitLogin)}>
                <div className={styles.fullInput}>
                  <label className={styles.loginLabel}>{t("mailAdress")}</label>
                  <input
                    className={styles.loginInput}
                    type="email"
                    placeholder={t("mailPlaceholder")}
                    {...registerLogin("email", {
                      required: true,
                      pattern:
                        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    })}
                  />
                </div>
                {errorsLogin.email && (
                  <span className={styles.formErrors}>{t("emptyMail")}</span>
                )}
                <div
                  className={
                    styles["fullInput"] + " " + styles["fullInputBottom"]
                  }
                >
                  <label className={styles.loginLabel}>{t("password")}</label>
                  <i
                    className={styles.inputEye}
                    onClick={() => {
                      setShowPassword(!showPassword);
                    }}
                  >
                    {!showPassword ? <FaRegEye /> : <FaRegEyeSlash />}
                  </i>

                  <input
                    className={styles.loginInput}
                    type={showPassword === false ? "password" : "text"}
                    placeholder={t("passwordPlaceholder")}
                    {...registerLogin("password", {
                      required: true,
                      pattern:
                        /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^:;,?µ£¨<>+=&*-\x2D]).{12,}$/,
                    })}
                  />
                </div>
                {showPasswordError ? (
                  <p className={styles.modalPasswordError}>
                    {t("incorrectPassword")}
                  </p>
                ) : null}
                {errorsLogin.password && (
                  <span className={styles.formErrors}>
                    {t("passwordFormat")}
                  </span>
                )}
                <div className={styles.loginFormButtons}>
                  <input
                    type="button"
                    className={styles.registerButton}
                    value={t("openAccount")}
                    onClick={() => {
                      showRegister();
                    }}
                  />
                  <input
                    type="submit"
                    className={styles.loginButton}
                    value={t("login")}
                    onSubmit={onSubmitLogin}
                  />
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
